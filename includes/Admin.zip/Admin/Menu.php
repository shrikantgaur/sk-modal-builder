<?php

class SK_Modal_Admin_Menu {

    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
    }

    public function menu() {

        add_menu_page(
            'SK Modal Builder',
            'SK Modals',
            'manage_options',
            'sk-modal-builder',
            [$this, 'dashboard'],
            'dashicons-welcome-widgets-menus',
            6
        );

        add_submenu_page(
            'sk-modal-builder',
            'All Modals',
            'All Modals',
            'manage_options',
            'edit.php?post_type=sk_modal'
        );

        add_submenu_page(
            'sk-modal-builder',
            'Settings',
            'Settings',
            'manage_options',
            'sk-modal-settings',
            [$this, 'settings']
        );
    }

    public function dashboard() {
        echo '<div class="wrap"><h1>SK Modal Builder</h1><p>Create & manage modals.</p></div>';
    }

    public function settings() {
        echo '<div class="wrap"><h1>Settings</h1></div>';
    }
}
