<?php
/**
 * Silence is golden.
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}?>

<h1>Hello</h1>