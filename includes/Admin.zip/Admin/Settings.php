<?php

class SK_Modal_Admin_Settings {

    public function __construct() {
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings() {
        register_setting('sk_modal_options', 'sk_modal_builder_settings');
    }
}
new SK_Modal_Admin_Settings();
