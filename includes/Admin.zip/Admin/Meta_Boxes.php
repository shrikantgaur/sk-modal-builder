<?php

class SK_Modal_Admin_Meta_Boxes {

    public function __construct() {
        add_action('add_meta_boxes', [$this, 'register_meta_boxes']);
    }

    public function register_meta_boxes() {
        add_meta_box(
            'sk_modal_settings',
            __('Modal Settings', 'sk-modal-builder'),
            [$this, 'render_meta_box'],
            'sk_modal',
            'normal',
            'default'
        );
    }

    public function render_meta_box($post) {
        $trigger = get_post_meta($post->ID, '_sk_modal_trigger', true);
        echo '<label>' . __('Trigger Event', 'sk-modal-builder') . '</label>';
        echo '<select name="sk_modal_trigger">';
        echo '<option value="click" ' . selected($trigger, 'click', false) . '>Click</option>';
        echo '<option value="load" ' . selected($trigger, 'load', false) . '>Page Load</option>';
        echo '</select>';
    }
}
new SK_Modal_Admin_Meta_Boxes();
